package com.example.stockspring.dao;
/*
public class StockExchangeDaoIml implements StockExchangeDao {

	@Override
	public void insert(StockExchangeDao stockExchangeDao) {
		// TODO Auto-generated method stub
		

	}

}*/
